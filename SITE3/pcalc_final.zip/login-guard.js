// login e guarda de sessão extraído do script.js
