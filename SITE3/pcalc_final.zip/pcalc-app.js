// inicialização principal da calculadora
