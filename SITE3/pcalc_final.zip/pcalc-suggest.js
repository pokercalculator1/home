// lógica de sugestão de ações
