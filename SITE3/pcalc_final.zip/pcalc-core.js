// utilidades e estado
