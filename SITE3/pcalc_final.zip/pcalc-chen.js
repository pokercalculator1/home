// lógica de cálculo Chen pré-flop
