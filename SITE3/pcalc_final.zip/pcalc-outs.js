// cálculo e renderização dos outs
